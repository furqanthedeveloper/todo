
import 'package:flutter/material.dart';
import 'package:flutter/widgets.dart';
import 'package:todoapp/utils/todolist.dart';

class HomePage extends StatefulWidget {
  const HomePage({super.key});

  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  final controller =TextEditingController();
  List todoList = [
    ['Web Development',false],
    ['Drink Coffe',false],
  ];

  void CheckBoxchanged(int index){
    setState(() {
    todoList[index][1]=!todoList[index][1];  
    });
    
  }
  void saveNewTask(){
    setState(() {
      todoList.add([controller.text,false]);
      controller.clear();
    });
  }
  void deleteTask(int index){
    setState(() {
      todoList.removeAt(index);
    });
  }
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.deepOrange.shade300,
      appBar: AppBar(
        title:const Text(
          "Todoapp"
          ),
          backgroundColor: Colors.deepOrange,
          foregroundColor: Colors.white,
          ),
          body: ListView.builder(
            itemCount: todoList.length, 
            itemBuilder: (BuildContext context,index){
            return TodoList(
              taskName:todoList[index][0],
              taskCompleted: todoList[index][1],
              onChanged: (value)=>CheckBoxchanged(index), 
              deleteFunction:(contex)=> deleteTask(index),
            ); 
          },
          ),
          floatingActionButton: Padding(
            padding: const EdgeInsets.symmetric(horizontal:20),
            child: Row(
              children: [
                 Expanded(
                  child: Padding(
                    padding: const EdgeInsets.symmetric(
                      horizontal: 20,
                      ),
                    child: TextField(
                      controller: controller,
                      decoration: InputDecoration(
                        hintText: 'Add a new todo items',
                        filled: true,
                        fillColor: Colors.deepOrange.shade300,
                        enabledBorder:OutlineInputBorder(
                          borderSide: const BorderSide(
                            color: Colors.deepOrange,
                          ),
                          borderRadius: BorderRadius.circular(15), 
                          ),
                          focusedBorder: OutlineInputBorder(
                            borderSide: const BorderSide(
                              color: Colors.deepOrange,
                            ),
                            borderRadius: BorderRadius.circular(15), 
                          ),
                         ),
                    ),
                  ),
                  ),
                FloatingActionButton(
                  onPressed:saveNewTask,
                  child: const Icon(Icons.add), 
                  ),
              ],
            ),
          ),
    );
  }
}